from django.http.response import HttpResponse, JsonResponse

from .models import Company, Vacancy

def company_list(request):
  companies = Company.objects.all()
  companies_json = [company.to_json() for company in companies]
  return JsonResponse(companies_json, safe=False)

def company_detail(request, id):
  company = Company.objects.get(id=id)
  return JsonResponse(company.to_json())

def vacancy_list(request):
  vacancies = Vacancy.objects.all()
  vacancies_json = [vacancy.to_json() for vacancy in vacancies]
  return JsonResponse(vacancies_json, safe=False)

def vacancy_detail(request, id):
  vacancy = Vacancy.objects.get(id=id)
  return JsonResponse(vacancy.to_json())

def vacancy_topten(request):
  vacancies = Vacancy.objects.order_by('-salary')[:10]
  vacancies_json = [vacancy.to_json() for vacancy in vacancies]
  return JsonResponse(vacancies_json, safe=False)

def company_vacancy_list(request, id):
  vacancies = Vacancy.objects.filter(company_id = id)
  vacancies_json = [vacancy.to_json() for vacancy in vacancies]
  return JsonResponse(vacancies_json, safe=False)