from django.urls import path
from .views import company_list, company_detail, vacancy_list, vacancy_detail, company_vacancy_list, vacancy_topten

app_name = "companies"

urlpatterns = [
    path('companies/', company_list),
    path('companies/<int:id>', company_detail),
    path('vacancies/', vacancy_list),
    path('vacancies/<int:id>', vacancy_detail),
    path('companies/<int:id>/vacancies', company_vacancy_list),
    path('vacancies_topten', vacancy_topten),
]