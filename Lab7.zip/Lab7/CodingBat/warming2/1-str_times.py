def string_times(str, n):
  result = ""
  for i in range(n): 
    result = result + str
  return result