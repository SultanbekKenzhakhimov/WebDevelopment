arr=input().split()
a=int(arr[0])
n=int(arr[1])

def power(a,n):
    return a**n


print(power(a,n))