n=int(input())
i=1
while i*i<=n:
    print(i*i)
    i=i+1