sum=0
for i in range(100):
    a=int(input())
    sum=sum+a
print(sum)