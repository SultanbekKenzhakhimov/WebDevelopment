sum=0
n=int(input())
for i in range(n):
    a=int(input())
    sum=sum+a
print(sum)