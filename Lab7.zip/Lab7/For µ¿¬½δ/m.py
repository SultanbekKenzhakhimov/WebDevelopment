cnt=0
n=int(input())
for i in range(n):
    a=int(input())
    if a==0:
        cnt=cnt+1
print(cnt)