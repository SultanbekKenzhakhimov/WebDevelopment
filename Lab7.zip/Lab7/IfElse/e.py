a=int(input())
b=int(input())
if a>b:
    print(1)
elif b>a:
    print(2)
else:
    print(0)