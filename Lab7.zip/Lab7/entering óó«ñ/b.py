a=int(input())
print("The next number for the number " + str(a) + " is " + str(a+1) + ".")
print("The previous number for the number " + str(a) + " is " + str(a-1)+".")